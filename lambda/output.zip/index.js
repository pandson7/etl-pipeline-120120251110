const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { DynamoDBClient, GetItemCommand } = require('@aws-sdk/client-dynamodb');

const s3 = new S3Client({});
const dynamodb = new DynamoDBClient({});

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  try {
    const jobId = event.pathParameters.jobId;
    const isDownload = event.queryStringParameters?.download === 'true';

    const jobResult = await dynamodb.send(new GetItemCommand({
      TableName: process.env.JOBS_TABLE,
      Key: { jobId: { S: jobId } },
    }));

    if (!jobResult.Item || !jobResult.Item.outputS3Key) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: 'Output not found' }),
      };
    }

    const s3Key = jobResult.Item.outputS3Key.S;

    if (isDownload) {
      const command = new GetObjectCommand({
        Bucket: process.env.OUTPUT_BUCKET,
        Key: s3Key,
      });
      const downloadUrl = await getSignedUrl(s3, command, { expiresIn: 3600 });
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ downloadUrl }),
      };
    } else {
      const result = await s3.send(new GetObjectCommand({
        Bucket: process.env.OUTPUT_BUCKET,
        Key: s3Key,
      }));

      const content = await result.Body.transformToString();
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ content }),
      };
    }
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
